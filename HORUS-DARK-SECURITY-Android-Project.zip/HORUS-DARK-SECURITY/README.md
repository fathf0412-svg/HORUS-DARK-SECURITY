# HORUS DARK SECURITY

Android starter project (Kotlin, native UI). Includes:
- Local password-strength estimate (password field clears after analysis; password is not written to a file).
- Basic URL-format warnings.
- Latest in-memory report display.

## Build an APK
This project includes a GitHub Actions workflow:
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run **Build HORUS APK** (or push to `main`).
4. Open the completed workflow run and download the `HORUS-DARK-SECURITY-debug` artifact.
5. Extract it to get `app-debug.apk`, then install it on your Android phone.

The debug APK is for testing. The app performs basic local checks only; it does not crack passwords, verify website reputation, or guarantee safety. Do not test with a real account password.
