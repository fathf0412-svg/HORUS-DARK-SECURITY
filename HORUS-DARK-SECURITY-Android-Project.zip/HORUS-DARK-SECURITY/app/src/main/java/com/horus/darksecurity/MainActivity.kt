package com.horus.darksecurity

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.net.URI

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 12)
    private val panel = Color.rgb(25, 24, 28)
    private val red = Color.rgb(225, 55, 45)
    private val orange = Color.rgb(255, 115, 35)
    private val white = Color.rgb(245, 242, 240)
    private lateinit var output: TextView
    private lateinit var passwordInput: EditText
    private lateinit var urlInput: EditText
    private var lastReport = "No analysis has been run yet."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 28)
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "HORUS"
            textSize = 34f
            setTextColor(orange)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "DARK SECURITY  •  LOCAL CHECKS"
            textSize = 13f
            setTextColor(white)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, matchWrap())

        root.addView(section("PASSWORD INTELLIGENCE"))
        passwordInput = EditText(this).apply {
            hint = "Enter a test password (never share a real one)"
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setBackgroundColor(panel)
            setPadding(14, 12, 14, 12)
        }
        root.addView(passwordInput, matchWrap())
        root.addView(button("ANALYZE PASSWORD") { analyzePassword() })

        root.addView(section("URL / PHISHING FORMAT CHECK"))
        urlInput = EditText(this).apply {
            hint = "example.com"
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setBackgroundColor(panel)
            setPadding(14, 12, 14, 12)
        }
        root.addView(urlInput, matchWrap())
        root.addView(button("ANALYZE URL") { analyzeUrl() })

        root.addView(section("SECURITY REPORT"))
        output = TextView(this).apply {
            text = "Results appear here.\n\nAll checks run locally. Password text is not saved."
            textSize = 15f
            setTextColor(white)
            setPadding(16, 16, 16, 16)
            setBackgroundColor(panel)
        }
        root.addView(output, matchWrap())
        root.addView(button("SHOW LATEST REPORT") { output.text = lastReport })
        val note = TextView(this).apply {
            text = "\nHORUS 1.0 • Basic defensive checks only\nA clean result does not prove a site is safe."
            setTextColor(Color.LTGRAY)
            textSize = 12f
            gravity = Gravity.CENTER
        }
        root.addView(note, matchWrap())
    }

    private fun section(text: String): TextView = TextView(this).apply {
        this.text = "\n$text"
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(red)
        setPadding(0, 18, 0, 8)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(red)
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.setMargins(0, 10, 0, 8)
        layoutParams = p
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun analyzePassword() {
        val value = passwordInput.text?.toString().orEmpty()
        if (value.isEmpty()) {
            output.text = "Enter a test password first."
            return
        }
        var score = 0
        val checks = listOf(
            value.length >= 12,
            value.any { it.isLowerCase() },
            value.any { it.isUpperCase() },
            value.any { it.isDigit() },
            value.any { !it.isLetterOrDigit() },
            value.length >= 16
        )
        score = checks.count { it } * 100 / checks.size
        val level = when {
            score < 35 -> "WEAK"
            score < 70 -> "MODERATE"
            else -> "STRONGER"
        }
        val tips = mutableListOf<String>()
        if (value.length < 12) tips.add("Use at least 12 characters; longer is generally better.")
        if (!value.any { it.isLowerCase() } || !value.any { it.isUpperCase() }) tips.add("Consider a mix of letter cases.")
        if (!value.any { it.isDigit() }) tips.add("Consider adding numbers.")
        if (!value.any { !it.isLetterOrDigit() }) tips.add("Consider adding a symbol, if the service allows it.")
        if (tips.isEmpty()) tips.add("Use a unique passphrase for every account and enable two-step verification.")
        val report = "PASSWORD SECURITY REPORT\nScore: $score/100\nAssessment: $level\n\nChecks passed: ${checks.count { it }} of ${checks.size}\n\nRecommendations:\n• " +
            tips.joinToString("\n• ") +
            "\n\nPrivacy: the password itself is not displayed in this report or stored by HORUS."
        lastReport = report
        output.text = report
        passwordInput.text?.clear()
    }

    private fun analyzeUrl() {
        val raw = urlInput.text?.toString()?.trim().orEmpty()
        if (raw.isEmpty()) {
            output.text = "Enter a URL first."
            return
        }
        val candidate = if (raw.contains("://")) raw else "https://$raw"
        try {
            val uri = URI(candidate)
            val host = uri.host?.lowercase()
            if (host.isNullOrBlank()) {
                output.text = "Invalid URL format. Check the address and try again."
                return
            }
            val warnings = mutableListOf<String>()
            if (!uri.scheme.equals("https", true)) warnings.add("The address does not use HTTPS.")
            if (uri.rawAuthority?.contains("@") == true) warnings.add("The address contains an unusual @ symbol.")
            if (host.contains("facebook") && host != "facebook.com" && host != "www.facebook.com") {
                warnings.add("The word Facebook appears in a hostname other than facebook.com.")
            }
            val result = buildString {
                append("URL ANALYSIS REPORT\nHostname: $host\nHTTPS: ${uri.scheme.equals("https", true)}\n")
                if (warnings.isEmpty()) append("\nNo basic format warning detected.")
                else append("\nWarnings:\n• " + warnings.joinToString("\n• "))
                append("\n\nThis is a local format check, not a reputation scan. Never enter passwords after following an unexpected link.")
            }
            lastReport = result
            output.text = result
        } catch (_: Exception) {
            output.text = "Could not parse this address. Check its format."
        }
    }
}
